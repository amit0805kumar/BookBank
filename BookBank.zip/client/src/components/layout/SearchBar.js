import React from 'react'

const SearchBar = () => {
    return (
        <React.Fragment>
            <div className="searchContainer">
                <input type="text" placeholder="Search" />
            </div>
        </React.Fragment>
    )
}

export default SearchBar
